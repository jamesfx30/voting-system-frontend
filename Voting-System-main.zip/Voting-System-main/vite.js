    import { defineConfig } from 'vite';
    import react from '@vitejs/plugin-react';

    // https://vitejs.dev/config/
    export default defineConfig({
      plugins: [react()],
      resolve: {
        alias: {
          // This should directly map '@' to the 'src' directory
          // assuming 'src' is a direct child of the project root.
          '@': '/src',
        },
      },
      server: {
        host: 'localhost',
        port: 5173, // Ensure this matches your desired frontend port
      },
    });
    